format long
g = 9.81;
T0 = [1.9;5.6];
T1 = [5.7;3.2];
v0 = 0; %zacetna hitrost

%1. Kolik�en je �as potovanja kroglice od T0 do T1 po krivulji k?

odg1 = min(y)
cas1 = brahistohrona(T0,T1)




%%???????
%2
T0 = [1.9;5.6];
T1 = [5.7;3.2];
T2 = [7;3.2];

dolzina = sqrt((T2(1) - T1(1))^2 + (T2(2) - T1(2))^2);
hitrost = brahistohrona1(T0,T1); %hitrost po premici je enaka itrosti v T1


%za drugo ne dobivamo hitrosti, ker je vodoravna izracunamo samo razdaljo
dolzina = sqrt((T2(1) - T1(1))^2 + (T2(2) - T1(2))^2);

%dobimo koliko casa potuje po drugi
cas_premice = dolzina ./ hitrost;

%skupen cas da pride do konca
skupniCas = cas1 + cas_premice



%3. Kolik�na je hitrost kroglice na krivulji k v to�ki T1?
hitrosti = brahistohrona1(T0,T1);
odg3 = hitrosti(end)

%4. Kolik�na je najve�ja hitrost kroglice na krivulji k?
hitrosti = brahistohrona1(T0,T1);
odg4 = max(hitrosti) 





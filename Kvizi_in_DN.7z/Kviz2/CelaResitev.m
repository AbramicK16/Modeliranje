format long
T0 = [2.2;3];
T1 = [6;1.6];
M = [1.0,2.0,4.0,2.0,1.0,2.0];
L = [1.0,1.5,1.0,1.0,1.0,1.5];
g = 9.81;
w0 = [-1;-1];

%1.Kolik�na je potencialna energija veri�nice? 
potencilna = diskrVeriznica1(w0, T0, T1, L, M, g)

%b
y = x(2,:);
n = length(y);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y(i) + y(i+1))/2;
    vsota = vsota + vrednost * M(i);
end
odg1 = vsota*g


%2 Denimo, da bi vsak �lenek veri�nice razdelili na 3 enaki 
%polovici (vmes bi vstavili gibljiv zglob). 
%Kolik�na bi bila najni�ja to�ka veri�nice?
M = [1.0,2.0,4.0,2.0,1.0,2.0];
L = [1.0,1.5,1.0,1.0,1.0,1.5];
M1 = [0.333333333333333,0.333333333333333,0.333333333333333,0.666666666666667,0.666666666666667,0.666666666666667,1.333333333333333,1.333333333333333,1.333333333333333,0.666666666666667,0.666666666666667,0.666666666666667,0.333333333333333,0.333333333333333,0.333333333333333,0.666666666666667,0.666666666666667,0.666666666666667];
L1 = [0.333333333333333,0.333333333333333,0.333333333333333,0.500000000000000,0.500000000000000,0.500000000000000,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.333333333333333,0.500000000000000,0.500000000000000,0.500000000000000];
x1 = diskrVeriznica(w0, T0, T1, L1, M1);
najnizjaOrdinata = min(x1(2,:))


%3
x3 = diskrVeriznica([1;1], T0, T1, L, M)
y3 = x3(2,:);
n = length(y3);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y3(i) + y3(i+1))/2;
    vsota = vsota + vrednost * M(i);
end
odg3 = vsota*g


%4Denimo, da sredinsko kraji��e veri�nice navpi�no dvignemo 
%iz ravnovesne lege, oblika veri�nice se primerno spremeni. 
%Za koliko bi morali dvigniti kraji��e, da bi bila potencialna
%energija veri�nice enaka 180?
sredisce = length(M) / 2 + 1; 
L1 = L(1: sredisce - 1); %do sredisca - prva veriznica
M1 = M(1: sredisce - 1);
L2 = L(sredisce: end); %od sredisca naprej - druga veriznica
M2 = M(sredisce: end);
vmes = @(p) [x(1,sredisce); x(2,sredisce) + p];
f = @(p) (diskrVeriznica1(w0, T0, vmes(p), L1, M1, g) + diskrVeriznica1(w0, vmes(p), T1, L2, M2, g) - 180);
p = fsolve(f,0)

Mm = @(m) [1.0,2.0,4.0 * m ,2.0,1.0,2.0];
L = [1.0,1.5,1.0,1.0,1.0,1.5];
f1 = @(m) (diskrVeriznica1(w0, T0,T1, L, Mm(m), g) + diskrVeriznica1(w0, T0, T1, L, Mm(m), g) <= 120);
odg4 = fsolve(f1,0)

%5

%b
Tl = [1; 5];
Td = [8.5; 0];

veri = diskrVeriznica(w0,Tl, Td, L, M ); %od tod dobim koordinato �estega �lenka
%ne pride ok, upo�tevam samo, da se koordinata zamakne v levo za 2,5

Td1 = [6; 0];
M5 = [1 2 1 2 1 2];
L5 = [1 1.5 1 1.5 1 1.5];
x2 = diskrVeriznica(w0, T0, [6;0], L5, M5)
y = x2(2,:);
n = length(y);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y(i) + y(i+1))/2;
    vsota = vsota + vrednost * M5(i);
end
odg5 = vsota*g

%%%%%%2 Naloga
T0 = [1;5];
T2 = [6;2];
t = [3;2];
g = 9.81

%1 Kolik�en je �as potovanja kroglice od T0 do T1 po krivulji k?
cas = brahi(T0,T1)

h = 3; %razlika v vi�ini to?ke T1 in T2 oz T3

%2.2 - ?as potovanja kroglice po odsekoma linearni krivulji, ki potka skozi
%T1 [3;2] in T2
%ker je funkcija odsekoma linearna iz to?e T1 T3 upo�tevamo zakon o
%ohranitvi energije T1 - potencialna, T3 - kineti?na, kjer dobimo hitrost,
%ki jo upo�tevamo po tem ko se kroglica pelje po ravni podlagi od T3 do T2
% m*g*h = 0.5*m*v^2
T3 = [3; 2];
brahistohrona(T1, T3);
v = sqrt(2*g*h);
cas_t3dot2 = h/v;
cas_premica = 0.939921411395149; %iz brahistohrone
odg22 = cas_premica + cas_t3dot2

%2.3 - najve?ja hitrost kroglice na krivlji k
odg23 = v

%2.4 - najve?ja hitrost kroglice na krivulji k
hitrosti = brahistohrona1(T0, T1);
odgovor24 = max(hitrosti)


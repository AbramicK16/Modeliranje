format long
T0 = [1.9;5.6];
T1 = [5.7;3.2];
g = 9.81;

%1
%a.)primer
b = T1(1)-T0(1);
B = T1(2)-T0(2);
% poiscemo optimalni theta (in pripadajoci k)
[theta0,k] = poisciOpt_theta_k(b,B);
% definiramo diskr. vrednosti parametricne krivulje v odvisnosti od parametra theta
theta = linspace(0,theta0,100000); %spremeni theta! 
y = -1/2*k^2*(1-cos(theta)) + T0(2);
minY = min(y)

%2
casBrah = brahi(T0,T1);
T2 = [7;3.2];

%dolzina premice
d1 = sqrt((T1(1)-T2(1)).^2 + (T1(2)-T2(2)).^2);

%hitrost v tocki T1
visina = T0(2)-T1(2);
hitrost = sqrt(2*g*visina);

%cas po premici
casPremica = d1 / hitrost;

skupniCas = casBrah + casPremica

%3
odg3 = T0(1);
% Tn = @(x) [x; 5.6];
% g = @(x) (brahi(T0, Tn(x)) - brahi(Tn(x), T1));
% rez = fsolve(g,2*pi);
% odg3b = min(rez)

%4
T0 = [1.9;5.6];
Tn = @(x) [x; 5.6];
T1 = [5.7;3.2];
cas = @(x) (brahi(T0,Tn(x)) - brahi(Tn(x),T1));
x_koor = fsolve(cas,2*pi) %pravi rezultat = 3.2086620207674
%5
%koliko je hitrost po 1 �asovni enoti?
hitrost5 = brahiHitrost(T0,T1,1)

%b primer
b = T1(1)-T0(1);
B = T1(2)-T0(2);
% poiscemo optimalni theta (in pripadajoci k)
[theta0,k] = poisciOpt_theta_k(b,B);
theta0Opt = 1*sqrt(2*9.81)/k;
yOpt = -1/2*k^2*(1-cos(theta0Opt)) + T0(2);
odg5 = sqrt(2*g*(T0(2)-yOpt))


function hitrostVcasu = brahiHitrost(T1,T2,cas)

b = T2(1)-T1(1);
B = T2(2)-T1(2);
[theta, k] = poisciOpt_theta_k(b, B);
y =  @(theta) k^2/2 * (cos(theta(1)) - 1);
%t0 = [1.0]; %definiramo eno tocko
%th = fminsearch(y, t0)
%t = linspace(0, theta);
nov_theta = cas * (2 * 9.81) ^ 0.5 / k;
hitrostVcasu = (2 * 9.81 * abs(y(nov_theta))) .^ 0.5;

end
obesisceL = [0, 5];
obesisceD = [5, 3];
L = 20;
tol = 10 ^(-6);
%T_min = zvVeriznica(obesisceL,obesisceD,L,tol); 
%T_min(1) % drugo vprašanje kviz

% 4 odgovor izpiše vmes
%T_min1 = zvVeriznica1(obesisceL,obesisceD,L,tol); 

%5 odgovor -> moral sem desno obesišče razbiti na dva dela, drugače se je
%matlab pritoževal
%b = obesisceD(1);
%fsolve(@(p) zvVeriznica2(obesisceL, b, (p), L, tol) - 2.5, 3)
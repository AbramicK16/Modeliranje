format long
%1 NALOGA
dat = load('costs.mat');
mojaTabela = dat.costs; 
b = [4, 9, 12, 14, 16, 18, 19, 20, 21, 22, 23, 25, 26, 27, 29];
minimum = 100;
maksimum = -1;
maks_razlika = [];
k = 1;
for i = b
    for j = 1: 25
         st = mojaTabela(j, i);
         if st > maksimum
             maksimum = st;
         elseif st < minimum
                minimum = st;
         end
    end
    min3 = min(mojaTabela(:, i));
    max3 = max(mojaTabela(:, i));
    maks_razlika(k) = max3 - min3;
    k = k + 1;
    
end
%1 vprašanje
%maksimum - minimum

%3 vprašanje
%max(maks_razlika)

omejitev = 10000;
sez_strosek = [];
k = 1;
rez = 0;
logicna = 1;
for j = 1: 25
    strosek = 0;
    for i = b
         st = mojaTabela(j, i);
         strosek = strosek + st;
         omejitev = omejitev - st;
         if omejitev < 0 & logicna == 1
            rez = sum(sez_strosek);
            logicna = 2;
         end
    end
    sez_strosek(k) = strosek;
    k = k + 1;
end
%2 vprašanje
%max(sez_strosek)

%4 vprašanje
%rez


%2 NALOGA
obesisceL = [0; 10];
obesisceD = [10; 10];
M = [6, 1, 8, 1, 7, 10, 4, 8, 7, 10];
L = [1.2, 1.6, 2, 1.3, 1.5, 1.6, 1.4, 1.5, 1.8, 1.1];
w0 = [-1; -1];
%x = diskrVeriznica1(w0,obesisceL,obesisceD,L,M)
% 1 vprašanje
%min(x(2, :))
% L1 = @(p) [1.2, 1.6, 2, 1.3, 1.5 + p, 1.6 + p, 1.4, 1.5, 1.8, 1.1];
% 2 vprašanje
% fsolve(@(p)diskrVeriznica2(w0,obesisceL,obesisceD,L1(p),M), 0)
% 
% L2 = @(p) p .* [1.2, 1.6, 2, 1.3, 1.5, 1.6, 1.4, 1.5, 1.8, 1.1];
% 3 vprašanje
% fsolve(@(p)diskrVeriznica2(w0,obesisceL,obesisceD,L2(p),M), 0)
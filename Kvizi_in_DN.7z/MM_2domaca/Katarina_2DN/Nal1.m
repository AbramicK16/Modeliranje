format long
T0 = [1;5];
T1 = [6;2];
M = [1,2,1,2,1,2,1,2];
L = [1,1.5,1,1.5,1,1.5,1,1.5];
g = 9.81;
w0 = [-1;-1];

%1.  Kolik�na je povpre�na vrednost abscis vseh kraji��, 
%ki sestavljajo veri�nico?
x = diskrVeriznica(w0, T0, T1, L, M);
povprecna_vrednost = mean(x(1,:)); %gledamo x koordinato
odg1 = povprecna_vrednost

%2. Kolik�na je potencialna energija veri�nice?
potencilna = diskrVeriznica1(w0, T0, T1, L, M, g)

%%%%%%%
potencilna1 = 0;
for i = 1 :length(M) 
    potencilna1 = potencilna1 + g * M(i) * (x(2, i) + x(2, i + 1)) / 2;
end

potencilna1;

%3. Denimo, da bi vsak �lenek veri�nice razdelili na dve enaki
%polovici (vmes bi vstavili gibljiv zglob). 
%Kolik�na bi bila najni�ja to�ka veri�nice?
L3 = [];
M3 = [];
j = 1;
for i = 1: length(M)
    dol_i = L(i);
    mas_i = M(i);
    L3(j) = dol_i / 2;
    M3(j) = mas_i / 2;
    j = j + 1;
    L3(j) = dol_i / 2;
    M3(j) = mas_i / 2;
    j = j + 1;
end

x3 = diskrVeriznica([-1; -1], T0, T1, L3, M3)
odg3 = min(x3(2, :))

M1 = [ 0.5 0.5 1 1 0.5 0.5 1 1 0.5 0.5 1 1 0.5 0.5 1 1 ]; %vsako maso razpolovimo
%vsako dolzino razpolovimo
L1 = [0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75];
razpolovljena = diskrVeriznica(w0, T0, T1, L1, M1);
odg13 = min(razpolovljena(2,:)) %i��emo y to�ko (minimum)


%?????????????????
%4.
sredisce = length(M) / 2 + 1; 
L1 = L(1: sredisce - 1); %do sredisca - prva veriznica
M1 = M(1: sredisce - 1);
L2 = L(sredisce: end); %od sredisca naprej - druga veriznica
M2 = M(sredisce: end);
%tocka v srediscu
vmes = @(p)[x(1, sredisce); x(2, sredisce) + p]; %y koordinato dvignemo za p
f = @(p)(diskrVeriznica1([-1; -1], T0, vmes(p), L1, M1, g) + diskrVeriznica1([-1; -1], vmes(p), T1, L2, M2, g) - 180);
odg4 = fsolve(f, 0)

%5
T11 = [8.5,0]';
T00 = [1, 5]';
w0 = [-1; -1];
tocke = diskrVeriznica(w0, T00, T11, L, M);
tocke(tocke < 0) = 0; 
kje = find(tocke(2,:)==0);
prva_nicla = tocke(:, kje(1));
prva_nicla(1) = tocke(1, end) - sum(L(kje(1): end));
% da vidimo sliko
% hold on
% x = diskrVeriznica(w0, T00, prva_nicla, L(1:kje(1) - 1), M(1: kje(1) - 1));
odgovor15 = diskrVeriznica1(w0, T00, prva_nicla, L(1:kje(1) - 1), M(1: kje(1) - 1), g)

%%%%5
Tl = [1; 5];
Td = [8.5; 0];

veri = diskrVeriznica(w0,Tl, Td, L, M ); %od tod dobim koordinato �estega �lenka
%ne pride ok, upo�tevam samo, da se koordinata zamakne v levo za 2,5

Td1 = [6; 0];
M5 = [1 2 1 2 1 2];
L5 = [1 1.5 1 1.5 1 1.5];
x2 = diskrVeriznica(w0, T0, [6;0], L5, M5)
y = x2(2,:);
n = length(y);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y(i) + y(i+1))/2;
    vsota = vsota + vrednost * M5(i);
end
odg5 = vsota*g


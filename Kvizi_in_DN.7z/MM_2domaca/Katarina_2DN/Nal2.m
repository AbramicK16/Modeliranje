format long
g = 9.81;
T0 = [1;5];
T1 = [6;2];
t = [3;2];
v0 = 0; %zacetna hitrost

%1. Kolik�en je �as potovanja kroglice od T0 do T1 po krivulji k? 
odg1 = brahistohrona(T0,T1)


%%???????
%2. Izra�unajte �as potovanja kroglice po odsekoma linearni
%krivulji, ki poteka skozi to�ke T0, [3,2]? in T1.
T0 = [1;5];
T1 = [6;2];
t = [3;2];
% izra�un �asa od T0  do to�ke t
t = t - T0;
T1 = T1 - T0;
T0 = [0; 0];
k_pre1 = (T0(2) - t(2)) / (T0(1) - t(1));
y1 = @(x) k_pre1 .* x + T0(2) - k_pre1 * T0(1);
f1 = @(x) ((1 + k_pre1 ^ 2) ./ (2 * 9.81 .* abs(y1(x)))) .^ 0.5;
cas1 = integral(f1, 0, t(1));
% ker imata naslednji dve točki enak y je treba upoštevati hitrost
hitrost = (2 * g * abs(t(2))) .^ 0.5
cas2 = (T1(1) - t(1)) / (hitrost);
odg2 = cas1 + cas2

%%%%%
v = sqrt(2*g*3); % 3 = abs(B) = (t(2)-T0(2)) 
t2 = v / 3;
b = t(1)-T0(1);
B = t(2)-T0(2);
cas_premica = sqrt(2*(b^2+B^2)/(-9.8*B));
skupni = t2 + cas_premica

%3. Kolik�na je hitrost kroglice na krivulji k v to�ki T1?
hitrosti = brahistohrona1(T0,T1);
odg3 = hitrosti(end)

%4. Kolik�na je najve�ja hitrost kroglice na krivulji k?
hitrosti = brahistohrona1(T0,T1);
odg4 = max(hitrosti) 


%%%????????????????????????
%5. Originalno brahistohrono z desne strani podalj�amo na ve�ji
%interval tako, da se s k ujema med T0 in T1. 
% Dolo�ite to�ko T2, kjer je �as potovanja od T0 do T2 ravno 1.5. 
%Koliko je ?T2?2?
kol_casa = 1.5;
odgovor25 = brahistohrona2(T0, T1, kol_casa)


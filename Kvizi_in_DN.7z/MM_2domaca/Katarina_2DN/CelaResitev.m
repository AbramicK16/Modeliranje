format long
T0 = [1;5];
T1 = [6;2];
M = [1,2,1,2,1,2,1,2];
L = [1,1.5,1,1.5,1,1.5,1,1.5];
g = 9.81;
w0 = [-1;-1];

%1 Kolik�na je povpre�na vrednost abscis vseh kraji��, 
%ki sestavljajo veri�nico?
x = diskrVeriznica(w0, T0, T1, L, M);
abscise = mean(x(1,:))

%2.Kolik�na je potencialna energija veri�nice? 
potencilna1 = 0;
for i = 1 :length(M) 
    potencilna1 = potencilna1 + g * M(i) * (x(2, i) + x(2, i + 1)) / 2;
end

potencilna1

%3 Denimo, da bi vsak �lenek veri�nice razdelili na dve enaki 
%polovici (vmes bi vstavili gibljiv zglob). 
%Kolik�na bi bila najni�ja to�ka veri�nice?
M1 = [0.5,0.5,1,1,0.5,0.5,1,1,0.5,0.5,1,1,0.5,0.5,1,1];
L1 = [0.5,0.5,0.75,0.75,0.5,0.5,0.75,0.75,0.5,0.5,0.75,0.75,0.5,0.5,0.75,0.75];
x1 = diskrVeriznica(w0, T0, T1, L1, M1);
najnizjaOrdinata = min(x1(2,:))

%4Denimo, da sredinsko kraji��e veri�nice navpi�no dvignemo 
%iz ravnovesne lege, oblika veri�nice se primerno spremeni. 
%Za koliko bi morali dvigniti kraji��e, da bi bila potencialna
%energija veri�nice enaka 180?
sredisce = length(M) / 2 + 1; 
L1 = L(1: sredisce - 1); %do sredisca - prva veriznica
M1 = M(1: sredisce - 1);
L2 = L(sredisce: end); %od sredisca naprej - druga veriznica
M2 = M(sredisce: end);
vmes = @(p) [x(1,sredisce); x(2,sredisce) + p];
f = @(p) (diskrVeriznica1(w0, T0, vmes(p), L1, M1, g) + diskrVeriznica1(w0, vmes(p), T1, L2, M2, g) - 180);
p = fsolve(f,0)

%5
T11 = [8.5,0]';
T00 = [1, 5]';
w0 = [-1; -1];
tocke = diskrVeriznica(w0, T00, T11, L, M);
tocke(tocke < 0) = 0; 
kje = find(tocke(2,:)==0);
prva_nicla = tocke(:, kje(1));
prva_nicla(1) = tocke(1, end) - sum(L(kje(1): end));
% da vidimo sliko
% hold on
% x = diskrVeriznica(w0, T00, prva_nicla, L(1:kje(1) - 1), M(1: kje(1) - 1));
odgovor15 = diskrVeriznica1(w0, T00, prva_nicla, L(1:kje(1) - 1), M(1: kje(1) - 1), g)

Tl = [1; 5];
Td = [8.5; 0];

veri = diskrVeriznica(w0,Tl, Td, L, M ); %od tod dobim koordinato �estega �lenka
%ne pride ok, upo�tevam samo, da se koordinata zamakne v levo za 2,5

Td1 = [6; 0];
M5 = [1 2 1 2 1 2];
L5 = [1 1.5 1 1.5 1 1.5];
x2 = diskrVeriznica(w0, T0, [6;0], L5, M5)
y = x2(2,:);
n = length(y);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y(i) + y(i+1))/2;
    vsota = vsota + vrednost * M5(i);
end
odg5 = vsota*g

%%%%%%2 Naloga
T0 = [1;5];
T2 = [6;2];
t = [3;2];
g = 9.81

%1 Kolik�en je �as potovanja kroglice od T0 do T1 po krivulji k?
cas = brahi(T0,T1)

h = 3; %razlika v vi�ini to?ke T1 in T2 oz T3

%2.2 - ?as potovanja kroglice po odsekoma linearni krivulji, ki potka skozi
%T1 [3;2] in T2
%ker je funkcija odsekoma linearna iz to?e T1 T3 upo�tevamo zakon o
%ohranitvi energije T1 - potencialna, T3 - kineti?na, kjer dobimo hitrost,
%ki jo upo�tevamo po tem ko se kroglica pelje po ravni podlagi od T3 do T2
% m*g*h = 0.5*m*v^2
T3 = [3; 2];
brahistohrona(T1, T3);
v = sqrt(2*g*h);
cas_t3dot2 = h/v;
cas_premica = 0.939921411395149; %iz brahistohrone
odg22 = cas_premica + cas_t3dot2

%2.3 - najve?ja hitrost kroglice na krivlji k
odg23 = v

%2.4 - najve?ja hitrost kroglice na krivulji k
odg24 = max(hitrosti(T1, T2))


format long
g = 9.81;
T0 = [1;5];
T1 = [6;2];
T01 = [3;2];
%1 Kolik�en je �as potovanja kroglice od T0 do T1 po krivulji k?
casBrahi = brahistohrona(T0,T1)

%2 ???? Neki ne �tima! ????
%izracunamo obe dolzini premic
g = 9.81; T0 = [1;5]; T1 = [6;2]; T01 = [3;2];

d1 = sqrt((T0(1)-T01(1)).^2 + (T0(2)-T01(2)).^2);
d2 = sqrt((T01(1)-T1(1)).^2 + (T01(2)-T1(2)).^2);

%izracunamo hitrost
h = 3; %visina
hitrost = sqrt(2*g*h);

%izracunamo cas premic
b = T01(1)-T0(1);
B = T01(2)-T0(2);
%cas_premica = 0.940400840863405; %funkcija brahis
cas1 = sqrt(2*(b^2+B^2)/(-g*B)); %prva premica
cas2 = d2/hitrost; %druga premica
casSkupni = cas1 + cas2 % dobim 1.410361546560980

%3 Kolik�na je hitrost kroglice na krivulji k v to�ki T1?
h = 3; %visina
hitrost = sqrt(2*g*h)

%4 Kolik�na je najve�ja hitrost kroglice na krivulji k?

%a primer
% b = T1(1)-T0(1);
% B = T1(2)-T0(2);
% [theta0,k] = poisciOpt_theta_k(b,B);
% theta = linspace(0,theta0,1000);
% x = 1/2*k^2*(theta-sin(theta)) + T1(1);
% y = -1/2*k^2*(1-cos(theta)) + T1(2);
% hitr4 = sqrt(2*g*abs(y));
% Max = max(hitr4)


%b primer
% T1 = T1 - T0;
% b = T1(1);
% B = T1(2);
% [theta, k] = poisciOpt_theta_k(b, B);
% y = @(theta) k ^ 2 / 2 * (cos(theta) - 1);
% t = linspace(0, theta);
% hitrosti4 = (2 * 9.81 * abs(y(t))) .^ 0.5;
% max(hitrosti4)

%c primer
% b = T1(1)-T0(1);
% B = T1(2)-T0(2);
% [theta, k] = poisciOpt_theta_k(b, B);
% y =  @(theta) k^2/2 * (cos(theta(1)) - 1);
% t0 = [1.0]; %definiramo eno tocko
% th = fminsearch(y, t0)
% hitrost4 = (2 * 9.81 * abs(y(th))) .^ 0.5
% odg4 = max(hitrost4)

%d
T1 = [1;5];
T2 = [6;2];
b = T2(1)-T1(1);
B = T2(2)-T1(2);
% poiscemo optimalni theta (in pripadajoci k)
[theta0,k] = poisciOpt_theta_k(b,B);
% definiramo diskr. vrednosti parametricne krivulje v odvisnosti od parametra theta
%theta = linspace(0,theta0,100000);
int_theta = linspace(1,theta0)
y = -1/2*k^2*(1-cos(int_theta));
minY = min(y)
najvecjaHitrost = sqrt(2 * 9.81 * (-min(y)))


T1 = [1;5];
T2 = [6;2];
b = T2(1)-T1(1);
B = T2(2)-T1(2);
% poiscemo optimalni theta (in pripadajoci k)
[theta0,k] = poisciOpt_theta_k(b,B);
% definiramo diskr. vrednosti parametricne krivulje v odvisnosti od parametra theta
theta = linspace(1,theta0);
y = -1/2*k^2*(1-cos(theta));
minyi = min(y);
najHitr = sqrt(2 * 9.81 * (-min(y)))

%5

%cas = k/sqrt(2*9.81)*theta0;
%k je �e pora�unan in sedaj samo da� not �eljeni �as in preme�e�:
%1.5 = k/sqrt(2*9.81)*theta0;
k = 1.733900230507511;
theta05 = 1.5/k*sqrt(2*9.81)
%theta05 = (sqrt(2*9.81)*1.5)/k

x = 1/2*k^2*(theta05-sin(theta05)) + T0(1);
y = -1/2*k^2*(1-cos(theta05)) + T0(2);
%in potem norma od tele to�ke in to je to.
T2 = [x;y];
odg5 = norm(T2)
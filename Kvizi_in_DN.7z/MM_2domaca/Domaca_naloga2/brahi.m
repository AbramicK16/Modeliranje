function cas = brahi(T1,T2)
% function brahistohrona(T1,T2)
% 
% Funkcija narise brahistohrono za robni tocki T1 in T2.
%
% vhod
% T1=[x_1;y1]; T_2=[x_2;y_2]
%

% Funkcija izpise tudi cas potovanja po brahistohroni ter za primerjavo cas potovanja po premici
% in paraboli med danima tockama.
% naredimo premik tock:
b = T2(1)-T1(1);
B = T2(2)-T1(2);
% poiscemo optimalni theta (in pripadajoci k)
[theta0,k] = poisciOpt_theta_k(b,B);
% definiramo diskr. vrednosti parametricne krivulje v odvisnosti od parametra theta
theta = linspace(0,theta0,100);
x = 1/2*k^2*(theta-sin(theta)) + T1(1);
y = -1/2*k^2*(1-cos(theta)) + T1(2);

% narisemo krivuljo
hold on;
plot(x,y,'b');
grid;
axis equal;

% cas potovanja po cikloidi, \int_{0,theta0} sqrt((1+y'^2)/(-2gy))*(dx/dtheta) dtheta = \int_{0,theta0} k/sqrt(2*g) dtheta:
cas = k/sqrt(2*9.81)*theta0


%%%%%%%%%%%%%
% premica
%%%%%%%%%%%%%
th = linspace(0,b,100);
plot(th + T1(1),B/b*th + T1(2),'r')

% cas potovanja po premici, \int_{0,b} sqrt((1+y'^2)/(-2gy))* dtheta = \int_{0,b} sqrt(-(b^2 + B^2)/(2*b*B*g*th)) dtheta :
cas_premica = sqrt(2*(b^2+B^2)/(-9.8*B))

%%%%%%%%%%%%%

% parabola
%%%%%%%%%%%%%

% parabola, ki se zacne v T1 in konca v T2 in ima vodoravno tangento v T2

th = linspace(0,b,1000);
c2 = B/(b.^2 + (-2*b)*b);
c1 = -2*c2*b;
y = @(x) c2*x.^2 + c1*x; % y = c2*x.^2 + c1*x;
plot(th + T1(1),y(th) + T1(2),'g')

% cas potovanja po paraboli, \int_{0,b} sqrt((1+y'^2)/(-2gy))* dtheta = ...
g = 9.8;
int = @(th) sqrt((b^4 + (2*B*th - 2*b*B).^2) ./ (2*b^2*B*g*th.*(th - 2*b)));
cas_parabola = integral(int,0,b,'RelTol',0,'AbsTol',1e-12)



legend('brah', 'lin', 'kvad')
end
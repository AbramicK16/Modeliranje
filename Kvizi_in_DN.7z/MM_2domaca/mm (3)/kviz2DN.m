%RE�ITVE KVIZA
format long
%podatki
w0 = [-1, -1];
obesisceL = [1; 5];
obesisceD = [6; 2];
M = [1 2 1 2 1 2 1 2];
L = [1 1.5 1 1.5 1 1.5 1 1.5];
g = 9.81;

%1. NALOGA - DISKRETNA VERI�NICA
%1.1 - povpre?na vrednost abscis
povpr_vrednost = diskrVer(w0, obesisceL, obesisceD, L, M);
odg11 = mean(povpr_vrednost(1,:))


%1.2 - potencialna energija veri�nice
%po formuli (3.5) Egon Zakraj�ek o Diskretni veri�nici
y = povpr_vrednost(2,:);
n = length(y);
vsota = 0;
for i = 1:(n-1)
    vrednost = (y(i) + y(i+1))/2;
    vsota = vsota + vrednost * M(i);
end
odg12 = vsota*g


%1.3 - najni�ja to?ka veri�nice, ?e vsak ?lenek damo na pol
%rapolovljene mase in dol�ine
M1 = [ 0.5 0.5 1 1 0.5 0.5 1 1 0.5 0.5 1 1 0.5 0.5 1 1 ];
L1 = [0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75 0.5 0.5 0.75 0.75];
razpolovljena = diskrVer(w0, obesisceL, obesisceD, L1, M1);
odg13 = min(razpolovljena(2,:)) %i�?emo y koo.


%1.4 - sredinsko kraji�?e veri�nice dvignemo navpi?no navzgor iz ravnovesne lege,
%  za koliko bi morali dvigniti kraji�?e, da bi bila potencialna energija enaka 180

%IDEJA: ra?unamo potencialno energijo za dve veri?nici, prva bo levi del
%s kraji�i obesisceL in sredisnko_krajisce. Druga analogno. Se�tevek
%potencialnih energij obeh veri�nic mora biti enak 180. sredinsko
%koordinato y enakomerno pove?ujemo navzgor, da bi ujeli pravo to?ko


%AMPAK, ali delam z original veri�nico ali z razpolovljenimi ?lenki??

sredinsko_krajisce = povpr_vrednost(:, round(n/2));
sredinska_x = sredinsko_krajisce(1);
sredinska_y = sredinsko_krajisce(2);

visinay = sredinska_y;
visinay2 = 1.075821184647270;

vsota = 0;
while abs(180 - vsota) > 10^-6
    sredina = (visinay2 + visinay)/2;
    vsota = PotEne(sredina);
    if vsota < 180
        visinay = sredina;
    else
        visinay2 = sredina;
    end
    
end
odg14 = sredina - sredinska_y





%1.5 - 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%DRUGA NALOGA

%2.1 - ?as potovanja kroglice od T1 do T2
%Podatki
T1 = [1;5];
T2 = [6;2];
odg21 = brahistohrona(T1,T2)
h = 3; %razlika v vi�ini to?ke T1 in T2 oz T3
%2.2 - ?as potovanja kroglice po odsekoma linearni krivulji, ki potka skozi
%T1 [3;2] in T2
%ker je funkcija odsekoma linearna iz to?e T1 T3 upo�tevamo zakon o
%ohranitvi energije T1 - potencialna, T3 - kineti?na, kjer dobimo hitrost,
%ki jo upo�tevamo po tem ko se kroglica pelje po ravni podlagi od T3 do T2
% m*g*h = 0.5*m*v^2

T3 = [3; 2];

brahistohrona(T1, T3);

v = sqrt(2*g*h);

cas_t3dot2 = h/v;

cas_premica = 0.939921411395149; %iz brahistohrone

odg22 = cas_premica + cas_t3dot2

%2.3 - najve?ja hitrost kroglice na krivlji k
odg23 = v

%2.4 - najve?ja hitrost kroglice na krivulji k
odg24 = max(hitrosti(T1, T2))






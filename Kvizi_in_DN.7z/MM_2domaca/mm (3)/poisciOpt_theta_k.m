function [theta,k] = poisciOpt_theta_k(b,B)
% function [theta,k] = poisciOpt_theta_k(b,B)
%
% Funkcija poisce netrivialen theta za brahistohrono, tako da g(theta)=0.
% Pogleg thete vrne tudi konstanto k.
%

% definiramo funkcijo g (konec strani 2)
g = @(theta) 1 - cos(theta) + B / b * (theta - sin(theta));

% resimo nelin. enacbo (s funkcijo fzero) --> theta, k
theta = fzero(g, 1);
k = sqrt(2 * b / (theta - sin(theta)));
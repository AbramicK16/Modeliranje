function cas = brahistohrona(T1,T2)
% function brahistohrona(T1,T2)
% 
% Funkcija narise brahistohrono za robni tocki T1 in T2.
%
% vhod
% T1=[x_1;y1]; T_2=[x_2;y_2]
%
% Funkcija vrne tudi cas potovanja po brahistohroni ter cas potovanja po premici
% in paraboli med danima tockama.

g = 9.81;

% naredimo premik tock "v izhodisce":
b = T2(1) - T1(1);
B = T2(2) - T1(2);

% poiscemo optimalni theta (in pripadajoci k)
[theta0, k] = poisciOpt_theta_k(b, B);

% definiramo diskr. vrednosti parametricne krivulje v odvisnosti od parametra theta
theta = linspace(0, theta0, 100);
x = 1/2 * k^2 * (theta - sin(theta)) + T1(1);
y = -1/2 * k^2 * (1 - cos(theta)) + T1(2);

cas = k / sqrt(2 * g) * theta0;
cas_premica = sqrt(2 * (b^2 + B^2) / (-g * B))

%int = @(th) sqrt((b^4 + (2*B*th - 2*b*B).^2) ./ (2*b^2*B*g*th.*(th - 2*b)));
%cas_parabola = integral(int, 0, b, 'RelTol', 0, 'AbsTol', 1e-12)

% narisemo krivuljo
%hold on;
%plot(x, y, 'b');
%grid;
%axis equal

end
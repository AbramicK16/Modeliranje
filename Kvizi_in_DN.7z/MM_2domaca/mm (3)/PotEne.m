function [potencialna] = PotEne(visinay)
%vhodni podatek:
%visinay - visina sredisnke tocke 
L = [1 1.5 1 1.5];
M = [1 2 1 2];
obesisceL = [1;5];
obesisce_srednja = [2.543175828723522;visinay]; %to?ka x je ves ?as enaka
obesisceD = [6;2];
w0=[-1;-1];
tocke_leva = diskrVer(w0,obesisceL,obesisce_srednja,L,M);
tocke_desna = diskrVer(w0,obesisce_srednja,obesisceD,L,M);

ipsiloni_levi = tocke_leva(2, :);
n = length(ipsiloni_levi);
potencialna_leva = 0;
for k = 1:(n-1)
    vrednost1 = (ipsiloni_levi(k)+ipsiloni_levi(k+1))/2;
    potencialna_leva = potencialna_leva + vrednost1*M(k);
end

ipsiloni_desni = tocke_desna(2, :);
potencialna_desna = 0;
for l = 1:(n-1)
    vrednost2 = (ipsiloni_desni(l)+ipsiloni_desni(l+1))/2;
    potencialna_desna = potencialna_desna + vrednost2*M(l);
end

potencialna = (potencialna_leva + potencialna_desna) * 9.81;

end
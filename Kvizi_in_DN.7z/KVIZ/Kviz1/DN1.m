format long

% 1. NALOGA

x1=linspace(0,5,101);
y1=linspace(0,5,101);
[X,Y]=ndgrid(x1,y1); %vedno uporabi ndgrid in ne meshgrid
%f = @(x,y) sin(sin(x+y))+ g;
g = @(x,y) 2.0*(exp(-4.0*((x-1.8).^2+(y-3.2).^2))+exp(-4.0*((x-1.0).^2+(y-2.0).^2))+exp(-3.7*((x-4.0).^2+(y-2.0).^2)));
f = @(x,y) sin(sin(x+y)) + g(x,y);
%f=@(x,y) sin(cos(x+y))+exp(-(x-1).^2-(y-1).^2);
%dfx=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(1)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
%dfy=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(2)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
A=f(X,Y);

% 1. VPRASANJE
[M1,I]=max(A);
[M,jmax]=max(M1);
imax=I(jmax);
jmax; %=20
odg1 = x1(jmax)



% 2. VPRASANJE
index_negativni = find(A<0);
negativni = A(index_negativni);
aritmetica_sredina = mean(negativni)

for j = 1:101
    tocka = f(x1(j),y1(j));
end
tocka

        
odg2 = max(min(A))






% 2. NALOGA

% izpisani podatki
h=40000; % skakalec skace z visine 40000m
g0=@(h) 9.81; % pospesek mora biti odvisen od h, zaradi kasnejsih nalog
m=104.0; % masa padalca+oprema
s=1.3; % presek padalca
kz=1.4; % koeficient upora zraka
n=10000; % casovne tocke
ro0=@(h) 1.225; % gostota zraka mora biti odvisna od h, zaradi kasnejsih nalog
tk=200; % cas meritve

visina = [0; 2000; 4000; 6000; 8000; 10000; 15000; 20000; 25000; 30000; 40000];
gostota = [1.225; 1.007; 0.8194; 0.6601; 0.5258; 0.4135; 0.1948; 0.08891; 0.04008; 0.01841; 0.003996];

p = [ones(11,1) ((visina-40000)./40000).^2 ((visina-40000)./40000).^4]; 
konstante = p\gostota;
ro=@(h) konstante(1)+konstante(2).*((h-40000)./40000).^2+konstante(3).*((h-40000)./40000).^4; % gostota zraka na razlicnih visinah

% 1. VPRASANJE
[y,v1,t]=padalec([m,kz,s],[h 0],tk,n,ro0,g0);
abs(v);
odg1 = max(abs(v1))


% 2. VPRASANJE
vd = 10;
hd = 10000;

[y1, v1, t1] = padalec([m, kz, s],[h 0],tk, n, ro0, g0);
[yd, vd, td] = padalec([m, kz, s],[hd vd],tk, n, ro0, g0);
odg2 = yd(end) - y1(end)



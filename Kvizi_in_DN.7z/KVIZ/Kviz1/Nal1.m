format long
%1Naloga

mreza_x = linspace(0, 5, 101);
mreza_y = linspace(0, 5, 101);
g = @(x) 2.0*(exp(-4.0*((x(1,:)-1.8)^2+(x(2,:)-3.2)^2))+exp(-4.0*((x(1,:)-1.0)^2+(x(2,:)-2.0)^2))+exp(-3.7*((x(1,:)-4.0)^2+(x(2,:)-2.0)^2)));
f = @(x) sin(sin(x(1,:)+x(2,:))) + g(x);

nicla = [0;0];
najf = f(nicla);


gladina = 0.5;
M = zeros(101);
naj_abs = 0;

for i = 1:101
    for j = 1:101
       for k = 1:101
            x = mreza_x(i);
            y = mreza_y(j);
            tocka = [x; y];
        
            potencialna_vrednost = f(tocka);
            
            odg2 = max(min(f(tocka)));
            
            if potencialna_vrednost >= gladina
                M(i, j) = potencialna_vrednost;
            
            end
        
                dodatna = mreza_y(k);
                tocka2 = [x; dodatna];
                rez = abs(f(tocka) - f(tocka2));
                if rez > naj_abs
                    naj_abs = rez;
                end
       end
    end
end
odg3 = naj_abs


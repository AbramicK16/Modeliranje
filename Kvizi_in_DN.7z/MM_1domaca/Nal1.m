format long
xi=linspace(0,5);
yj=linspace(0,5);
[X,Y]=meshgrid(x1,y1);
%f = @(x,y) sin(sin(x+y))+ g;
g = @(x,y) 2.0*(exp(-4.0*((x-1.8).^2+(y-3.2).^2))+exp(-4.0*((x-1.0).^2+(y-2.0).^2))+exp(-3.7*((x-4.0).^2+(y-2.0).^2)));
f = @(x,y) sin(sin(x+y)) + g(x,y);
%f=@(x,y) sin(cos(x+y))+exp(-(x-1).^2-(y-1).^2);
%dfx=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(1)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
%dfy=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(2)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
A=f(X,Y);

najvecji = -inf;
naj_x = -inf;
naj_y = -inf

stevec_neg = 0;
vsota_neg = 0;

negativna = zeros(n);

for i = 1 : 100
    for j= 1 : 100
        vrednost = f(xi(i), yj(j));
        if vrednost > najvecji
        
            najvecji = vrednost;
            naj_x = xi(i);
            naj_y = yj(j);
        end
    
        if vrednost < 0
        
            negativna(i,j) = vrednost;
      %stevec_neg = stevec_neg + 1;
      %vsota_neg = vsota_neg + vrednost;
        end
    end
end

%1
odg1 = norm([naj_x, naj_y],2)

%2
%odg2 = mean(vsota_neg);
rez2 = mean(nonzeros(negativna))

naj_razlika = -inf;

for i = 1 : 101
  for j = 1 : 101
    vrednost = f(xi(i), yj(j));
    prejsnja = f(xi(i + 1), yj(j));
    trenutna_razlika = abs(vrednost - prejsna);
    if trenutna_razlika > naj_razlika
      naj_razlika = trenutna_razlika;
    end
 end
end

%3
norm(naj_razlika)


x = 3;
y = 4;
%normalo potem se delimo da dobimo enotsko
normala = [-fx(x, y), -fy(x, y), 1] / sqrt(fx(x, y).^2 + fy(x, y).^2 + 1);

%4
normala(1)

fx = @(x) -2*exp(-(x(1) - 1)^2 - (x(2) - 1)^2) * (x(1) - 1) - cos(cos(x(1) + x(2))) * sin(x(1) + x(2));
fy = @(y) -2*exp(-(y(1) - 1)^2 - (y(2) - 1)^2) * (y(2) - 1) - cos(cos(y(1) + y(2))) * sin(y(1) + y(2));

x0 = [0.4, 0.4];

nicla = fsolve(@(x) [fx(x), fy(x)], x0);

%5
norm(nicla)







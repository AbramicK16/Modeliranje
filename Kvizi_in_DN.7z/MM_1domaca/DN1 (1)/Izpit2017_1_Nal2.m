format long
h = 300;
g0 = @(h) 9.8;
m = 62;
c = 1;
S = 1.5;
n = 100;
ro0 = @(h) 1.3;
tk = 9;

%1
parametri = [m,c,S];
zac = [h;0];
[y,v,t] = padalec5(parametri,zac,tk,n)
odg1 = mean(abs(v))
format long
H = 40000;
g = 9.81;
m = 104;
S = 1.3;
c = 1.4;

ro = 1.225;
tk = 200;
n = 10000;
parametri = [m,c,S];
zac = [40000;0];

%1
[y,v,t] = padalec(parametri,[40000 0],200,10000);
abs(v)
odgo = max(abs(v))




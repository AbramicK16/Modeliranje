format long
h = 40000;
g0 = @(h) 9.81;
m = 105;
c = 1;
S = 1.2;
n = 10000;
ro0 = @(h) 1.225;
tk = 300;

parametri = [m,c,S];
zac = [h;0];

%1
[y,v,t] = padalec(parametri,zac,tk,n,ro0,g0);
odg1 = mean(v)

%2
r = 6371000;
g = @(h) g0(h).*(r./(r+h)).^2;
%[y,v,t] = padalec(parametri,zac,tk,n);
[y,v1,t] = padalec(parametri,zac,tk,n,ro0,g);
odg2 = y(end)

%3
visina = [0;2000;4000;6000;8000;10000;15000;20000;25000;30000;40000];
gostota = [1.225;1.007;0.8194;0.6601;0.5258;0.4135;0.1948;0.08891;0.04008;0.01841;0.003996];
polinom = [ones(11,1) ((visina-40000)./40000).^2 ((visina-40000)./40000).^4];
konstante = polinom\gostota;
ro = @(h) konstante(1) + konstante(2).*((h-40000)./40000).^2 + konstante(3).*((h-40000)./40000).^4;
[y,v1,t] = padalec(parametri,zac,tk,n,ro,g);
odg3 = y(end)

%4
[y,v41,t] = padalec(parametri,[h;0],30,n,ro,g); %brez odriva
[y,v42,t] = padalec(parametri,[h;-3],30,n,ro,g); %z odrivom
razlika = v42(end) - v41(end)

%5
fun1=@(t) padalec1([m,kz,s],[h 0],t,cs,ro,g); % hitrost ob casu t
fun2=@(t) -300-fun1(t); 
odg5 = fsolve(fun2,30) % fun 2 ima niclo ravno pri tistem parametru,pri katerem ima fun1 vrednost 300


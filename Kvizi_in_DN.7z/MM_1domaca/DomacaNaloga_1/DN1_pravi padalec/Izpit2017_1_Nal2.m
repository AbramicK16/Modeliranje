format long
h = 300;
g0 = @(h) 9.8;
m = 62;
c = 1;
S = 1.5;
n = 100;
ro0 = @(h) 1.3;
tk = 9;

%1
parametri = [m,c,S];
zac = [h;0];
[y,v,t] = padalec(parametri,zac,tk,n,ro0,g0);
odg1 = max(abs(v))
visina = y(end) %1.193501629885966e+02
hitrost = v(end)
t

%2
[y,v,t1] = padalec(parametri,[h;0],tk,n,ro0,g0); %zacetna
[y,v,t2] = padalec(parametri,[1.193501629885966e+02;-24.920977457610320],tk,n,ro0,g0);
cas = 1/2*(t1-t2)

visinaMed = 0.5*(300 - 24.920977457610320)
cas = @(t) padalec(parametri,[h;0],tk,n,ro0,g0)

% fun1=@(t) 1/2*(padalec(parametri,[h;0],tk,n,ro0,g0) - padalec(parametri,[1.193501629885966e+02;-24.920977457610320],tk,n,ro0,g0));
% odg2 = fsolve(fun1,0)


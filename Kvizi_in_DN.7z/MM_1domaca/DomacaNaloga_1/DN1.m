format long

%1. NALOGA
x = linspace(0,5,100);
y = linspace(0,5,100);
[X,Y] = meshgrid(x,y); %rata matrika
f=@(x,y) sin(cos(x+y))+exp(-(x-1).^2-(y-1).^2);
dfx=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(1)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
dfy=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(2)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
A = f(X,Y);

%1. VPRASANJE
[M1,I] = max(A);
[M, jmax] = max(M1);
imax = I(jmax);
jmax;
odg1 = norm([x(9),y(9)])

%2.VPRASANJE
index_vsi_negativni = find(A < 0);
negativni = A(index_vsi_negativni);
odg2 = mean(negativni)

%3.VPRASANJE
razlike = diff(A,[],2); % diference - razlika med vrednostima
max_razlika = max(max(abs(razlike))) % maximalna razlika med vrednostima gledano absolutno

%4.VPRASANJE
x=3;
y=4;
% vektorski produkt odvoda po x in odvoda po y => dobimo normalo
normala = cross([1,0,dfx([x,y])],[0,1,dfy([x,y])]);
normala = normala/norm(normala);
normala(1)

%5.VPRASANJE
g=@(x) [dfx(x);dfy(x)];
nicla_parcialnih_odvodov = fsolve(g,[0.4,0.4]);
norma_nicla_parcialnih_odvodov = norm(nicla_parcialnih_odvodov)


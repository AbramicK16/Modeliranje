format long
h = 40000;
g0 = @(h) 9.81;
m = 105;
c = 1;
S = 1.2;
n = 10000;
ro0 = @(h) 1.225;
tk = 300;

[y,v,t] = padalec5(parametri,zac,tk,n);
odg1 = mean(abs(v))
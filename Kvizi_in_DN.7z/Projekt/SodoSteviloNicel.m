% Poi��emo ni�lo in nari�emo graf polinoma 4. stopnje
% f = @(x) -x^4 + 4*x^2 - 3
% a = -2;
% b = 2;

hold on
grid on
syms x
x = linspace(-2, 2, 100); 
f = @(x) -x.^4 + 4*x.^2 - 3
plot(x,f(x))
nicle = fzero(f,0)
%Nari�emo graf funkcije sin(x) na intervalu (-5*pi, 5*pi)
x=linspace(-5*pi, 5*pi, 5000)
y2 = sin(x);
nicle = [-4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi]; %vektor ni�el funkcije sin(x)
for k1 = 1:numel(nicle)
    z(k1) = fzero('sin(x)', nicle(k1));
end

%Nari�emo graf funkcije in dolo�imo x ter y os. 
figure
plot(x,y2,'-')
hold on
plot(z, zeros(size(z)), 'pg')        
hold off
%dolo�imo to�ke, ki bodo ozna�ene na x in y osi
xticklabels({'x = -4\pi','x = -3\pi','x = -2\pi', 'x=-\pi', 'x=0', 'x=\pi', 'x=2\pi', 'x=3\pi','x=4\pi', 'x=5\pi'})
yticks([-1 0 1])
yticklabels({'y = -1','y = 0','y = 1'})


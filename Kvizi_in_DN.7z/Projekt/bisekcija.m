function y = bisekcija(f,a,b,tol)
% Opis: Funkcija bisekcija izvede bisekcijo za iskanje ni�le dane funkcije na podanem
% intervalu.
%
% Definicija:
% y = bisekcija(f,a,b,razlika)
%
% Vhodni podatki: 
% f funkcija podana v obliki inline, a zacetek intervala
% b konec intervala
% tol absolutna razlika kraji�� glede na �irino za�etnega intervala
% Metoda bisekcije se konca, ko se krajisci 
% razlikujeta za manj kot 'tol', glede na sirino zacetnega intervala.
%
% Izhodni podatki: y ni�la funkcije

if sign(f(a))==sign(f(b)) 
   disp('Funkcija v robovih intervala ni nasprotno predznacena.');
   return
end
delta = tol*abs(b-a); %natan�neja toleranca, ki je odvisna od za�etne razdalje kraji�� intervala
while abs(b-a) > delta
    c = (a+b)/2; %sredina intervala
    if f(c) == 0 %ce smo �e takoj na�li niclo, jo vrnemo
        y = c;
        return
    end
    if sign(f(a)) == sign(f(c))
        a = c;
    else
        b = c;
    end
    y = c; 
end
function vektorVerjetnosti = bisekcijaVerjetnosti()
% Funkcija bisekcijaVerjetnosti vrne vektor verjetnosti, kolikokrat
% metoda bisekcija(f,a,b,razlika) najde i-to ni�ko na intervalu
% (-5*pi,5*pi), kjer je a naklju�no izbran na intervalu (-5*pi,-4*pi),
% b je pa naklju�no izbran na intervalu (4*pi, 5*pi).
%
%Izhod
%
%Ker ima funkcija sin(x) na zgoraj opisanem intervalu 9 ni�el, bo v 
% vektorju vektorVerjetnosti na vsakem indeksu se�tevek, kolikokrat 
%se je v metodi i-ta ni�la ponovila. Na koncu pa vsako vrednost iz tega 
%vektorja delimo s �tevilom korakov, da dobimo verjetnost. 

vektorVerjetnosti = zeros(1,9); %vektor z devetimi 0, kjer vsako �tevilo 0
%predstavlja eno ni�lo funkcije sin(x) na intervalu (-5*pi,5*pi)
for i = 1:2000
    f = @(x) sin(x);
    a = -pi*rand-4*pi; %nakljucno stevilo z intervala (-5*pi,-4*pi)
    b = pi*rand+4*pi; %nakljucno stevilo z intervala (5*pi,4*pi)
    nicla = bisekcija(f, a, b, 10^-3) %nicla najdena z bisekcijo
    stevilo = (nicla+5*pi)/pi
    indeksNicle = int32((nicla+5*pi)/pi) %indeks ni�le v vektorju vektorVerjetnosti
    %5*pi pri�etejmo, ker gledamo funkcijo od -5*pi naprej (v pozitivno smer).
    %Ni�le so za pi oddaljene med sabo, zato delimo s pi. 
    %Da dobimo pribli�no �tevilo, moramo deliti s pi in potem zaokro�it z int32
    vektorVerjetnosti(indeksNicle) = vektorVerjetnosti(indeksNicle) + 1
    %mesto v vektorVerjetnosti, kjer se nahaja indeksNicle, povecamo za 1
end
%verjetnost, kolikokrat metoda bisekcija najde i-to ni�lo
for i = 1:9
    vektorVerjetnosti(i) = vektorVerjetnosti(i)/2000;
end


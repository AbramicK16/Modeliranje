%Poi��imo ni�lo funkcije cos(x)

f = @(x) cos(x);
a = -4;
b = 4;
sredina = (a + b) / 2;
while abs(f(sredina)) > 0.01
    if (f(sredina) * f(b)) < 0
        a = sredina;
    else
        b = sredina;
    end
    sredina = (a + b) / 2;
end
%bis = bisekcija(f, a, b, 0.000001)
fprintf('Ni�la je %g\n', sredina) %izpis ni�le v konzolo
title('Primer bisekcije pri funkciji cos(x)') %naslov na grafu
xlabel('x-os') %oznaka za x os
ylabel('y-os') % oznaka za y os
hold on
grid on
syms x
x = linspace(-4,4,100);
f = @(x) cos(x);

% x = linspace(-3*pi/2, pi, 100); %100 to�k na intervalu
% f = @(x) cos(x);
 plot(x,f(x))
txt = '\leftarrow cos(x) = 0'; %ozna�ena ni�la s pu��ico na grafu
text(pi/2,f(pi/2),txt);
scatter(sredina,f(sredina))
hold off
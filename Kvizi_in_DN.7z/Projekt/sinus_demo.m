%Poi��imo ni�lo funkcije sin(x)

f = @(x) sin(x);
a = -4;
b = 4;
sredina = (a + b) / 2;
while abs(f(sredina)) > 0.01
    if (f(sredina) * f(b)) < 0
        a = sredina;
    else
        b = sredina;
    end
    sredina = (a + b) / 2;
end
fprintf('Ni�la je %g\n', sredina) %izpis ni�le v konzolo
title('Primer bisekcije pri funkciji sin(x)') %naslov na grafu
xlabel('x-os') %oznaka za x os
ylabel('y-os') % oznaka za y os
hold on
grid on
syms x
x = linspace(-2*pi, 2*pi, 100); %100 to�k na intervalu
f = @(x) sin(x);
plot(x,f(x))
txt = '\leftarrow sin(x) = 0'; %ozna�ena ni�la s pu��ico na grafu
text(0,f(0),txt);
scatter(sredina,f(sredina))
hold off
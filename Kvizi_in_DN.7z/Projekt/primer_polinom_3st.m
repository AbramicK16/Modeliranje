%Poi��emo ni�lo polinoma tretje stopnje

f = @(x) x.^3 - 5*x.^2 + 7*x - 3;
a = -2;
b = 4;

sredina = (a + b) / 2;

while abs(f(sredina)) > 0.01
    if (f(sredina) * f(b)) < 0
        a = sredina;
    else
        b = sredina;
    end
    sredina = (a + b) / 2;
end
fprintf('Ni�la je %g\n', sredina)  %izpis ni�le v konzolo
title('Primer bisekcije') %naslov na grafu
xlabel('x-os') %oznaka za x os
ylabel('y-os') %oznaka za y os
hold on
grid on
syms x
x = linspace(-2, 5, 100); 
f = @(x) x.^3 - 5*x.^2 + 7*x - 3;
plot(x,f(x))
txt = '\leftarrow x.^3 - 5*x.^2 + 7*x - 3 = 0'; %ozna�ena ni�la s pu��ico na grafu
text(1,f(1),txt);
scatter(sredina,f(sredina))
hold off



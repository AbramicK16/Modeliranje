%Nari�emo graf funkcije sin(x) na intervalu (-5*pi, 5*pi)

hold on
grid on
syms x
x = linspace(-5*pi, 5*pi, 5000); 
f = @(x) sin(x)
nicle = [-4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi]; %vektor ni�el
for k1 = 1:numel(nicle)
    z(k1) = fzero('sin(x)', nicle(k1));
end

figure
%plot(x,y2,'-')
%Nari�emo graf funkcije ter ozna�imo vse ni�le
hold on
grid on
plot(z, zeros(size(z)), 'b*')   
%dolo�imo to�ke, ki bodo ozna�ene na x in y osi
xticks([-5*pi -4*pi -3*pi -2*pi -pi 0 pi 2*pi 3*pi 4*pi 5*pi])
xticklabels({'x = -5\pi','x = -4\pi','x = -3\pi','x = -2\pi', 'x=-\pi', 'x=0', 'x=\pi', 'x=2\pi', 'x=3\pi','x=4\pi', 'x=5\pi','x = 5\pi'})
yticks([-1 0 1])
yticklabels({'y = -1','y = 0','y = 1'})
title('Funkcija sin(x)') %naslov na grafu
plot(x,f(x))


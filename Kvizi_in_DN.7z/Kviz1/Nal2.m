format long
h = 40000;
g0 = @(h) 9.81;
r = 6371000;
g = @(h) g0(h).*(r./(r+h)).^2;
m = 104.0;
S = 1.3;
c = 1.4;
ro0 = 1.225;
n = 10000;

visina = [0;2000;4000;6000;8000;10000;15000;20000;25000;30000;40000];
gostota = [1.225;1.007;0.8194;0.6601;0.5258;0.4135;0.1948;0.08891;0.04008;0.01841;0.003996];
polinom = [ones(11,1) ((visina-40000)./40000).^2 ((visina-40000)./40000).^4];
konstante = polinom\gostota;
ro = @(h) konstante(1) + konstante(2).*((h-40000)./40000).^2 + konstante(3).*((h-40000)./40000).^4;

%1
parametri = [m,c,S];
zac = [h;0];
tk = 200;
[y, v, t] = padalec1k(parametri, zac, tk, n);
max(abs(v))

[y,v1,t] = padalec3(parametri,zac,tk,n);
odg1 = max(abs(v1))

%2
[y, v, t] = padalec1k(parametri, zac, tk, n);
odg2 = y(end) - 10000 - 200*10

%3
%f3 = @(h) ro(h)-0.5
%odg3 = fzero(f3,0)
f3 = fzero(@(h) ro(h)-0.5, 0);
odg3 = f3

%4
tk = 300;
[y,v,t] = padalec(parametri,zac,tk,n,ro,g)
[y,v,t] = padalec([m c*5 S+10],[y(end) v(end)],100,n,ro,g);
odg4 = y(end)

%5
% v funkciji padalec spremenimo diferencialno enacbo: dodamo se vpliv sile

% dY = [Y(2); -sila/m-g(Y(1))-(1/2*ro(Y(1))*c(t)*S(t))/m*abs(Y(2)).*Y(2)];





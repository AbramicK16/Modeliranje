format long
m = 96;
h = 300;
c = 1;
S = 1.5;
ro = 1.3;
g = 9.8;
tk = 9;
n = 100;
parametri = [m,c,S];
zac = [0 h];
[y, v, t] = padalec1k(parametri, zac, tk, n);
abs(v)


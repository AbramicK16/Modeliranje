format long
x = linspace(0,5,101);
y = linspace(0,5,101);
[x2, y2] = ndgrid(x,y);
g = @(x,y) 2.0*(exp(-4.0*((x-1.8).^2+(y-3.2).^2))+exp(-4.0*((x-1.0).^2+(y-2.0).^2))+exp(-3.7*((x-4.0).^2+(y-2.0).^2)));
f = @(x,y) sin(sin(x+y)) + g(x,y);
z2 = f(x2,y2);


surf(x2,y2,z2);
axis equal
hold on

% vpr1
mm1 = max(max(z2));
[fx,fy] = find(abs(z2-mm1)<10^-10);
odg1 = x(fx)


% vpr2

odg2 = max(min(z2));



% vpr3

odg3 = max(max(z2,[],2) - min(z2,[],2));



% vpr4

z2voda = z2;

z2voda(z2voda<.5) = .5;

odg4 = mean(z2voda(:));





% vpr5

mat1 = z2(1:50,1:50);

mat2 = z2(30:60,50:80);

mat3 = z2(70:100,30:70);

odg5 = mm1+mm2+mm3;
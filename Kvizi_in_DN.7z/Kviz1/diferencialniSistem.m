function dY = diferencialniSistem(t,Y,parametri,ro,g)
% function dY = diferencialniSistem(t,Y,parametri)
% Opisuje sistem dif. enacb za padalca pri navpicnem padu.
% Vhod:
% t je cas, Y = [y1;y2]
% Prva komponenta Y(1) predstavlja pozicijo.
% Druga komponenta Y(2) predstavlja hitrost.
% parametri = [m,c,S]
% Izhod:
% dY je sistem NDE, vrnemo desno stran sistema dY = F(t,Y)

%[m,c,s] = parametri;
m = parametri(1);
c = parametri(2);
s = parametri(3);
dY = [Y(2); -g(Y(1)) + Y(2).^2.*ro(Y(1)).*c.*s./(2.*m)]; 





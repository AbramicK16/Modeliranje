format long

% 1. NALOGA

x1=linspace(0,5,100);
y1=linspace(0,5,100);
[X,Y]=meshgrid(x1,y1);
f=@(x,y) sin(cos(x+y))+exp(-(x-1).^2-(y-1).^2);
dfx=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(1)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
dfy=@(x) -cos(cos(x(1)+x(2))).*sin(x(1)+x(2))-2.*(x(2)-1)*exp(-(x(1)-1).^2-(x(2)-1).^2);
A=f(X,Y);

% 1. VPRASANJE
[M1,I]=max(A);
[M,jmax]=max(M1);
imax=I(jmax);
jmax;
norm([x1(9), y1(9)]);

% 2. VPRASANJE
index_negativni = find(A<0);
negativni = A(index_negativni);
aritmetica_sredina = mean(negativni);

% 3. VPRASANJE
razlike = diff(A,1,2); % diference - razlika med vrednostima
max_razlika = max(max(abs(razlike))); % maximalna razlika med vrednostima gledano absolutno

% 4. VPRASANJE
x=3;
y=4;
% vektorski produkt odvoda po x in odvoda po y => dobimo normalo
normala = cross([1,0,dfx([x,y])],[0,1,dfy([x,y])]);
normala = normala/norm(normala);
normala(1);

% 5. VPRASANJE
g=@(x) [dfx(x);dfy(x)];
nicla_parcialnih_odvodov = fsolve(g,[0.4,0.4]);
norma_nicla_parcialnih_odvodov = norm(nicla_parcialnih_odvodov);


% 2. NALOGA

% izpisani podatki
h=40000; % skakalec skace z visine 40000m
g0=@(h) 9.81; % pospesek mora biti odvisen od h, zaradi kasnejsih nalog
m=105; % masa padalca+oprema
s=1.2; % presek padalca
kz=1; % koeficient upora zraka
cs=10000; % casovne tocke
ro0=@(h) 1.225; % gostota zraka mora biti odvisna od h, zaradi kasnejsih nalog
tk=300; % cas meritve

% 1. VPRASANJE
[y,v1,t]=padalec([m,kz,s],[h 0],tk,cs,ro0,g0);
mean(v1); % povprecna hitrost

% 2. VPRASANJE
r=6371*1000; 
g=@(h) g0(h).*(r./(r+h)).^2; % gravitacijski pospesek se spreminja z visino
[y2,v,t]=padalec([m,kz,s],[h 0],tk,cs,ro0,g);
y2(end); % visina padalca po 300s

% 3. VPRASANJE
visina = [0;2000;4000;6000;8000;10000;15000;20000;25000;30000;40000];
gostota = [1.225;1.007;0.8194;0.6601;0.5258;0.4135;0.1948;0.08891;0.04008;0.01841;0.003996];
polinom = [ones(11,1) ((visina-40000)./40000).^2 ((visina-40000)./40000).^4];
konstante = polinom\gostota;
ro=@(h) konstante(1)+konstante(2).*((h-40000)./40000).^2+konstante(3).*((h-40000)./40000).^4; % gostota zraka na razlicnih visinah
[y3,v,t]=padalec([m,kz,s],[h 0],tk,cs,ro,g);
y3(end); % visina padalca po 300s

% 4. VPRASANJE
[y,v41,t]=padalec([m,kz,s],[h 0],30,cs,ro,g); % brez zacetne hitrosti
[y,v42,t]=padalec([m,kz,s],[h -3],30,cs,ro,g); % z zacetno hitrostjo
% ni isti rezultat
v42(end)-v41(end)

% 5. VPRASANJE
fun1=@(t) padalec1([m,kz,s],[h 0],t,cs,ro,g); % hitrost ob casu t
fun2=@(t) -300-fun1(t); 
fsolve(fun2,30); % fun 2 ima niclo ravno pri tistem parametru,pri katerem ima fun1 vrednost 300

